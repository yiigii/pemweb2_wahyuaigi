<?php  
    phpinfo();
