<?php

// definisikan variables
$nama = 'Afghan Hanif Adiyat';
$umur = 20;
$berat = 65;

echo 'Nama : ' . $nama;
echo '<br/>Umur : ' . $umur . ' Tahun';
echo '<br/>Berat : ' . $berat . ' Kg';

echo "<br/>Hello $nama Apakabar";
