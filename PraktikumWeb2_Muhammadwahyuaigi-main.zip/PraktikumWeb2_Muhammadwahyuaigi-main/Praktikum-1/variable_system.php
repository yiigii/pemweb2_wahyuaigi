<?php
// variable system
echo 'Dokumen Root ' . $_SERVER["DOCUMENT_ROOT"];
echo '<br/>Nama File ' . $_SERVER["PHP_SELF"];
