<?php 
class Matakuliah_model extends CI_model{
	public $id;
	public $nama;
	public $sks;
	public $kode;
}
 ?>